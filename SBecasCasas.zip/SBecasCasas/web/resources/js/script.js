$(document).ready(function() {
    // document.getElementById('form:table').DataTable();
    $('#form > table').DataTable();
});