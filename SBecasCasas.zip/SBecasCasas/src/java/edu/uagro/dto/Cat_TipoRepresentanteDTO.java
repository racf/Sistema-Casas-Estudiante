package edu.uagro.dto;

/**
 *
 * @author magic
 */
public class Cat_TipoRepresentanteDTO {
    
    private int id;
    private String nombre;

    public Cat_TipoRepresentanteDTO() {
    
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
}
